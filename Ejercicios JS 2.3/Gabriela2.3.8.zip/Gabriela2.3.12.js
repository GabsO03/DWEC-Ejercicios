let numeroBebidas = parseInt(prompt("Indica cuantos chupitos has tomado"));

window.alert(numeroBebidas>0? "No puedes conducir": "Nos alegra que seas un conductor responsable");

