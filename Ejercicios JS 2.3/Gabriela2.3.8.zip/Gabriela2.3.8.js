let nombre = prompt("Introduce tu nombre");

if(nombre == "") nombre = prompt("No ha introducido ningún nombre");

window.alert("Bienvenido " + nombre);