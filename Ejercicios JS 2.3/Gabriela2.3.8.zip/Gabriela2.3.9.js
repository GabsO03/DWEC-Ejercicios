let numero = parseInt(prompt("Introduce un número"));

if(numero%2==0) window.alert("El número es par");
else window.alert("El número es impar");