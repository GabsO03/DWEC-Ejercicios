let estudiante = {
    nombre : "Gabriela",
    edad : 21,
    curso : 2
}

delete(estudiante.edad);

console.log(estudiante);