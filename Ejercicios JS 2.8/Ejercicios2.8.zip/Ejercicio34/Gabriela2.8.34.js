let empresa = {
    nombre : "Petroprix",
    ubicacion : "Jaen",
    empleados : {
        nombre : "Adrian",
        puesto : "Analista",
        salario : 18000
    }
}

console.log("Nombre de la empresa:", empresa.nombre);
console.log("Ubicación de la empresa:", empresa.ubicacion);
console.log("Nombre del empleado:", empresa.empleados.nombre);
console.log("Puesto del empleado:", empresa.empleados.puesto);
console.log("Salario del empleado:", empresa.empleados.salario);

