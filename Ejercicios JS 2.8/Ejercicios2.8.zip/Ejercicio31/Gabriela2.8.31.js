let coche = {
    marca : "Renault",
    modelo : "Clio",
    anyo : 2003
};

console.log(coche);

coche.anyo = 2014;
coche.color = "blanco";

console.log(coche);