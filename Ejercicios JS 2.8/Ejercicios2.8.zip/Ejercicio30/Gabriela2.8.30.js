let persona = new Object();
persona.nombre = "Aaron";
persona.edad = 13;
persona.ciudad = "Lima";

console.log("Nombre:", persona.nombre);
console.log("Edad:", persona.edad);
console.log("Ciudad:", persona.ciudad);