let set = new Set();

set.add(100);
set.add(200);
set.add(300);

set.delete(200);

console.log(set);