let set = new Set();
set.add(5);
set.add(10);
set.add(15);
set.add(20);

console.log("Cantidad de elementos que hay en el set " + set.size);