let set = new Set();
set.add(10);
set.add(20);
set.add(30);

console.log(set.has(20));