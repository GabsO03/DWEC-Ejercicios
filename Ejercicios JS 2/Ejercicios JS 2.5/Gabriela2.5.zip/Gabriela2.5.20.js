let toDoList = ["Caminar al perro", "Regar las plantas", "Beber agua", "Limpiar los zapatos", "Comprar pan"];
console.log(toDoList);

let index = toDoList.indexOf("Beber agua");
console.log(toDoList);

toDoList.splice(index,1);
console.log(toDoList);
