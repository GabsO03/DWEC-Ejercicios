let ensaladaDeFrutas = ["fresa", "naranja", "aguaymanto", "cocona", "chirimoya", "melocotón"];

console.log("Las frutas que hay en la ensalada son:");
for (let index = 0; index < ensaladaDeFrutas.length; index++) {
    console.log(ensaladaDeFrutas[index]);
}