let producto = new Map();

producto.set('producto',"Tv");
producto.set('precio',"500");
producto.set('cantidad',"1");

let cantidad = producto.size;
console.log(cantidad);