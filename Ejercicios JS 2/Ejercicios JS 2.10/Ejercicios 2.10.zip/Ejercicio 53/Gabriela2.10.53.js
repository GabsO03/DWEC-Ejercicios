let auto = new Map();

auto.set('marca','Toyota');
auto.set('modelo','Susuki');
auto.set('anyo','2018');

let existeModelo = auto.has('modelo');
console.log(existeModelo);