let persona = new Map();

persona.set('nombre',"Alex");
persona.set('apellido',"");
persona.set('edad',"20");

persona.delete('edad');
console.log(persona);