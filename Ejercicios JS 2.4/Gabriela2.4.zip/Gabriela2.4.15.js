function saludo() {
    alert("Bienvenido!");
}

