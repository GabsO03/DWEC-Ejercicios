function calculoMayor(num1, num2) {
    alert("El número mayor es " + ((num1>num2)?num1:(num2>num1)?num2:"ninguno, son iguales"));
}

calculoMayor(3,5);
calculoMayor(8,4);
calculoMayor(7,7);

