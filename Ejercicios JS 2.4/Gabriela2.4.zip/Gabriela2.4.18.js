function iterarArray(array) {
    for (let index = 0; index < array.length; index++) {
        console.log(array[index]);
    }
}

let array1 = [8, 9, 8, 7, 6, 8, 9];
let array2 = [5, 3, 6, 4, 5, 4, 6];
let array3 = [10, 15, 16, 13, 12, 14, 11];
console.log("array 1");
iterarArray(array1);
console.log("array 2");
iterarArray(array2);
console.log("array 3");
iterarArray(array3);