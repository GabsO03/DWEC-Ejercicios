let map = new Map();
map.set("nombre", "Gabi");
map.set("edad", 21);
map.set("ciudad", "Lima");

console.log(map);