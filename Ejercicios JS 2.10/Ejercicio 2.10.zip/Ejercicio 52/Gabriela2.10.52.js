let map = new Map();
map.set("nombre", "Gabi");
map.set("edad", 21);
map.set("ciudad", "Lima");

let nombre = map.get('nombre');
console.log(nombre);